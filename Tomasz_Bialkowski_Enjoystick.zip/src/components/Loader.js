export const Loader = () => <p className="loader">Loading...</p>;
