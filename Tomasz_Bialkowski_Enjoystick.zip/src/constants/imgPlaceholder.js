export const IMG_PLACEHOLDER = "/img/image-placeholder.jpg";
