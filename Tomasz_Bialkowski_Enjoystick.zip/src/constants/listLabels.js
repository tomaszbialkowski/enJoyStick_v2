export const ListLabel = {
  ALL: "All",
  HOT: "Hot",
  LAME: "Lame",
  FAVOURITE: "Favourite",
  PLAYED: "Played",
  FINISHED: "Finished",
};
