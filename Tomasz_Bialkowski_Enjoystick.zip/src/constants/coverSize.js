export const coverSize = {
  THUMB: "thumb",
  LARGE: "large",
};
